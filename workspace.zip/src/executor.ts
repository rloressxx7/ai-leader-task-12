import { Keypair, PublicKey, VersionedTransaction } from "@solana/web3.js";
import bs58 from "bs58";
import { setTimeout as delay } from "node:timers/promises";
import type { Config } from "./config.js";
import { log } from "./log.js";
import type { ExecutionResult, TradeExecutor } from "./types.js";
import { RpcPool, TransactionFailedError, type TokenBalance } from "./rpc-pool.js";

export function loadKeypair(secret: string): Keypair {
  const trimmed = secret.trim();
  const bytes = trimmed.startsWith("[")
    ? Uint8Array.from(JSON.parse(trimmed) as number[])
    : bs58.decode(trimmed);
  if (bytes.length !== 64) throw new Error(`WALLET_PRIVATE_KEY decoded to ${bytes.length} bytes; expected 64`);
  return Keypair.fromSecretKey(bytes);
}

export class PortalExecutor implements TradeExecutor {
  readonly publicKey: string;

  constructor(private readonly config: Config, private readonly rpc: RpcPool, private readonly signer: Keypair) {
    this.publicKey = signer.publicKey.toBase58();
  }

  async buy(mint: string, solAmount: number, pool: string): Promise<ExecutionResult> {
    const [before, transaction] = await Promise.all([
      this.rpc.getTokenBalance(this.publicKey, mint),
      this.buildSigned({
      publicKey: this.publicKey, action: "buy", mint, amount: solAmount,
      denominatedInSol: "true", slippage: this.config.SLIPPAGE_PCT,
      priorityFee: this.config.PRIORITY_FEE_SOL, pool
      })
    ]);
    const signature = await this.sendAndConfirm(transaction);
    const after = await this.balanceAfterSettlement(mint, before.amount, "increase");
    const acquired = after.amount - before.amount;
    if (acquired <= 0n) throw new Error(`Buy ${signature} confirmed without a positive token balance delta`);
    return { signature, tokenAmount: acquired, tokenDecimals: after.decimals };
  }

  async sell(mint: string, tokenAmount: bigint, tokenDecimals: number, pool: string): Promise<ExecutionResult> {
    if (tokenAmount <= 0n) throw new Error("Refusing zero-token sell");
    const amount = decimalUnits(tokenAmount, tokenDecimals);
    const [before, transaction] = await Promise.all([
      this.rpc.getTokenBalance(this.publicKey, mint),
      this.buildSigned({
      publicKey: this.publicKey, action: "sell", mint, amount,
      denominatedInSol: "false", slippage: this.config.SLIPPAGE_PCT,
      priorityFee: this.config.PRIORITY_FEE_SOL, pool
      })
    ]);
    const signature = await this.sendAndConfirm(transaction);
    const after = await this.balanceAfterSettlement(mint, before.amount, "decrease");
    const sold = before.amount - after.amount;
    if (sold <= 0n) throw new Error(`Sell ${signature} confirmed without a negative token balance delta`);
    return { signature, tokenAmount: sold, tokenDecimals: after.decimals };
  }

  private async buildSigned(body: Record<string, unknown>): Promise<Uint8Array> {
    new PublicKey(String(body.mint));
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.config.RPC_TIMEOUT_MS * 2);
    let response: Response;
    try {
      response = await fetch(this.config.PUMPPORTAL_TRADE_URL, {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify(body), signal: controller.signal
      });
    } finally { clearTimeout(timeout); }
    if (!response.ok) throw new Error(`Transaction builder HTTP ${response.status}: ${(await response.text()).slice(0, 500)}`);
    const bytes = new Uint8Array(await response.arrayBuffer());
    let transaction: VersionedTransaction;
    try { transaction = VersionedTransaction.deserialize(bytes); }
    catch { throw new Error(`Transaction builder returned invalid data: ${Buffer.from(bytes).toString("utf8", 0, 300)}`); }
    transaction.sign([this.signer]);
    return transaction.serialize();
  }

  private async sendAndConfirm(transaction: Uint8Array): Promise<string> {
    const signature = await this.rpc.sendRawTransaction(transaction, {
      skipPreflight: this.config.TX_SKIP_PREFLIGHT,
      maxRetries: this.config.TX_MAX_RETRIES
    });
    try {
      await this.rpc.confirm(signature, this.config.TX_CONFIRM_TIMEOUT_MS);
    } catch (error) {
      // An observed program error is definitive. Only transport/status uncertainty
      // is reconciled via balances; retrying a failed instruction cannot create a fill.
      if (error instanceof TransactionFailedError) throw error;
      // A timed-out status request must not trigger a second trade; the caller verifies the balance delta.
      log.warn({ signature, err: String(error) }, "Confirmation uncertain; reconciling from token balance");
    }
    return signature;
  }

  private async balanceAfterSettlement(mint: string, baseline: bigint, direction: "increase" | "decrease"): Promise<TokenBalance> {
    const deadline = Date.now() + this.config.TX_BALANCE_SETTLE_TIMEOUT_MS;
    let last = await this.rpc.getTokenBalance(this.publicKey, mint);
    let attempt = 0;
    while (Date.now() < deadline) {
      const balance = attempt++ === 0 ? last : await this.rpc.getTokenBalance(this.publicKey, mint);
      last = balance;
      if (direction === "increase" ? balance.amount > baseline : balance.amount < baseline) return balance;
      const remaining = deadline - Date.now();
      if (remaining > 0) await delay(Math.min(250 + attempt * 100, remaining));
    }
    return last;
  }
}

export class PaperExecutor implements TradeExecutor {
  private id = 0;
  async buy(_mint: string, _solAmount: number, _pool: string): Promise<ExecutionResult> {
    return { signature: `paper-buy-${Date.now()}-${++this.id}` };
  }
  async sell(_mint: string, tokenAmount: bigint, tokenDecimals: number, _pool: string): Promise<ExecutionResult> {
    return { signature: `paper-sell-${Date.now()}-${++this.id}`, tokenAmount, tokenDecimals };
  }
}

export function decimalUnits(raw: bigint, decimals: number): string {
  if (decimals === 0) return raw.toString();
  const scale = 10n ** BigInt(decimals);
  const whole = raw / scale;
  const fraction = (raw % scale).toString().padStart(decimals, "0").replace(/0+$/, "");
  return fraction ? `${whole}.${fraction}` : whole.toString();
}
