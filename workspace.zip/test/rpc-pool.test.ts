import { afterEach, describe, expect, it, vi } from "vitest";
import { RpcPool } from "../src/rpc-pool.js";

afterEach(() => vi.unstubAllGlobals());

describe("RpcPool", () => {
  it("rotates away from a rate-limited endpoint", async () => {
    const calls: string[] = [];
    vi.stubGlobal("fetch", vi.fn(async (input: string | URL | Request) => {
      const url = String(input);
      calls.push(url);
      if (url.includes("primary")) return new Response("rate limited", { status: 429, headers: { "retry-after": "0" } });
      return new Response(JSON.stringify({ jsonrpc: "2.0", id: 2, result: { value: 42 } }), { status: 200 });
    }));
    const pool = new RpcPool(["https://primary.example", "https://backup.example"], 1_000, 1_000);
    await expect(pool.request("getBalance", ["wallet"])).resolves.toEqual({ value: 42 });
    expect(calls).toEqual(["https://primary.example", "https://backup.example"]);
  });

  it("returns as soon as one broadcast endpoint accepts", async () => {
    vi.stubGlobal("fetch", vi.fn(async (input: string | URL | Request) => {
      if (String(input).includes("slow")) await new Promise((resolve) => setTimeout(resolve, 200));
      return new Response(JSON.stringify({ jsonrpc: "2.0", id: 1, result: "signature" }), { status: 200 });
    }));
    const pool = new RpcPool(["https://slow.example", "https://fast.example"], 1_000, 1_000);
    const started = Date.now();
    await expect(pool.sendRawTransaction(new Uint8Array([1]))).resolves.toBe("signature");
    expect(Date.now() - started).toBeLessThan(150);
  });

  it("surfaces an observed on-chain failure as a definitive error", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => new Response(JSON.stringify({
      jsonrpc: "2.0", id: 1, result: { value: [{ confirmationStatus: "processed", err: { InstructionError: [2, "Custom"] } }] }
    }), { status: 200 })));
    const pool = new RpcPool(["https://rpc.example"], 1_000, 1_000);
    await expect(pool.confirm("failed-signature", 100)).rejects.toMatchObject({
      name: "TransactionFailedError", signature: "failed-signature"
    });
  });
});
